import FormCourse from "../../components/ui/FormCourse";

export default function CreateCoursePage() {
  return (
    <>
      <h2>📝 Crear Nuevo Curso</h2>
      <FormCourse />
    </>
  );
}
