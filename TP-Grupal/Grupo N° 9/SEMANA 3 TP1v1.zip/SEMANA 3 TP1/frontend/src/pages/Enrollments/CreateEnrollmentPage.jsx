import FormEnrollment from "../../components/ui/FormEnrollment";

export default function CreateEnrollmentPage() {
  return (
    <>
      <h2>🧾 Registrar Inscripción</h2>
      <FormEnrollment />
    </>
  );
}
