import FormStudent from "../../components/ui/FormStudent";

export default function RegisterStudentPage() {
  return (
    <>
      <h2>🧾 Registrar Alumno</h2>
      <FormStudent />
    </>
  );
}
