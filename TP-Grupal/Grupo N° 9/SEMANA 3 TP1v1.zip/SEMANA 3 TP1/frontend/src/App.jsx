import AppRouter from "./router/AppRouter";
import "bootstrap/dist/css/bootstrap.min.css";

export default function App() {
  return <AppRouter />;
}
