export const ENDPOINTS = {
  COURSES: "/api/courses",
  STUDENTS: "/api/students",
  ENROLLMENTS: "/api/enrollments",
};
