// Constantes reutilizables
export const STORAGE_KEYS = {
  AUTH: 'tp_auth'
};
