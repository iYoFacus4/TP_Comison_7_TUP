// Placeholder de store (podés migrar a Context/Redux en semanas futuras)
export const appStore = {
  version: '1.0.0',
  grupo: '9'
};
