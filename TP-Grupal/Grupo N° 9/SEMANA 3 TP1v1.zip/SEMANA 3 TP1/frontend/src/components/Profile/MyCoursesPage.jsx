export default function MyCoursesPage() {
    return (
      <>
        <h2>🎓 Mis Cursos</h2>
        <p>Esta sección mostrará los cursos en los que el alumno está inscrito.</p>
      </>
    );
  }
  
